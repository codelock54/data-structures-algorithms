from Lista import *
if __name__ == "__main__":
    L = Lista()
    L.add(20)
    L.add(19)
    L.add(11)
    L.add(10)
    L.show()
