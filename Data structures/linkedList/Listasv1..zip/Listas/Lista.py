from Nodo import Nodo
class Lista:
    def __init__(self):
        self.head = None
    def getHead(self):
        return self.head
    def setHead(self, head):
        self.head = head
    def add(self, elemento):
        p = Nodo(elemento)
        #caso 1: head vacio
        if self.head is None:
            self.head = p
        else:
            p.setNext(self.head)
            self.head = p
    def show(self):
        t = self.head
        while t is not None:
            print(t, end=" ")
            t = t.getNext()
        print()