class Nodo:
    def __init__(self, valor):
        self.valor = valor
        self.next = None
    def getValor(self):
        return self.valor
    def setValor(self, valor):
        self.valor = valor
    def getNext(self):
        return self.next
    def setNext(self, nodo):
        self.next = nodo
    def __str__(self):
        return str(self.valor)